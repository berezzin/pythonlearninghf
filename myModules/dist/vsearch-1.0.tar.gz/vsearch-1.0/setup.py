from setuptools import setup

setup(name='vsearch',
      version='1.0',
      description='This is search module by Alex Berezin',
      author='Alex Berezin',
      py_modules=['vsearch'])
